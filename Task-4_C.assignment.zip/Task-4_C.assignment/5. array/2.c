#include <stdio.h>
int main() {
    char name[] = "Sritama"; // Replace with your name
    for(int i = 0; name[i] != '\0'; i++) printf("%c", name[i]);
    printf("\n");
    return 0;
}